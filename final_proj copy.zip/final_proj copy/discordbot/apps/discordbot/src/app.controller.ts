import { Controller } from '@nestjs/common';
import { On } from '@discord-nestjs/core';
import { Message } from 'discord.js';
import { AppService } from './app.service';

@Controller()
export class AppController {
  constructor(private readonly appService: AppService) {}

  @On('messageCreate')
  async onMessage(message: Message): Promise<void> {
    if (!message.author.bot) {
      const content = message.content.toLowerCase();

      if (content.startsWith('!send')) {
        const msg = content.split(' ')[1] || 'default message';
        await this.appService.sendMessageToCounter(msg);
        await message.channel.send(`Message sent to counter: ${msg}`);
      } else if (content === '!count') {
        const count = await this.appService.getCounter();
        await message.channel.send(`Current count is ${count}.`);
      }
    }
  }
}
